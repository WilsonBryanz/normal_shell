#!/bin/bash
ACTION=$1

[ -f /etc/profile ] && . /etc/profile >/dev/null

SYSTEM_TYPE=""

LAN_IF_ADDR=""

FIREWALL_LOG=""

BRIDGE_VALUE=""
MODEL=""
MARK="0x20/0x20"
OUT_MARK="0xf"
WORK_DIR="/tmp/xunyou"
XUNYOU_CHAIN="XUNYOU"
XUNYOU_ACC_CHAIN="XUNYOU_ACC"
XUNYOU_PROXY_CHAIN="XUNYOU_PROXY"
XUNYOU_CDN_CHAIN="XUNYOU_CDN"
TABLE_ID="95"
PROXY_PORT=9800
REDIRECT_TCP_PORT=9801
ACC_CONF="${WORK_DIR}/conf/accelerate"

PLUGIN_DOMAIN_HEX="|06|plugin|06|xunyou|03|com"
OLD_PLUGIN_DOMAIN_HEX="|0a|router-lan|10|xyrouterqpm3v2bi|02|cc"


get_json_value()
{
    local json=${1}
    local key=${2}
    local line=`echo ${json} | tr -d "\n " | awk -F"[][}{,]" '{for(i=1;i<=NF;i++) {if($i~/^"'${key}'":/) print $i}}' | tr -d '"' | sed -n 1p`
    local value=${line#*:}
    echo ${value}
}

env_init()
{
    local hostname=`uname -n`
    
    SYSTEM_TYPE="steam"
    MODEL="steam_deck"

    return 0
}

check_rule()
{
    return 0
}

config_acc_rule()
{
    systemd-resolve --flush-caches >/dev/null 2>&1

    
    ip rule add from all table 198
    ip rule add from all fwmark 0x199 table 199 >/dev/null 2>&1
    ip route add default via 172.19.199.1 dev tun199 table 199 >/dev/null 2>&1
    ip rule add from all fwmark 0x200 lookup main
    
    iptables -t nat -A POSTROUTING -o tun199 -j RETURN
    
    iptables -t filter -A INPUT -i tun199 -j ACCEPT
    iptables -t filter -A FORWARD -o tun199 -j ACCEPT
    iptables -t filter -A FORWARD -i tun199 -j ACCEPT
    
    iptables -t mangle -A INPUT -s 127.0.0.1/32 -p tcp -m tcp --dport 53 -j DROP
    
    iptables -t mangle -N XUNYOU
    iptables -t mangle -A OUTPUT -j XUNYOU
    iptables -t mangle -A XUNYOU -m mark --mark 0x200 -j ACCEPT
    iptables -t mangle -A XUNYOU -p udp -m udp --dport 1025:65535 -j MARK --set-xmark 0x199/0xffffffff
    iptables -t mangle -A XUNYOU -p udp -m udp --dport 53 -j MARK --set-xmark 0x199/0xffffffff
    iptables -t mangle -A XUNYOU -j ACCEPT
}

config_cdn_rule()
{
    local src_ip=$1
    local dst_ip=$2
    local dst_port=$3
    local redirect_port=$4
    
    iptables -t nat -n -L ${XUNYOU_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ];then
        iptables -t nat -N ${XUNYOU_CHAIN} >/dev/null 2>&1
    fi
    
    iptables -t nat -C  OUTPUT -j ${XUNYOU_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ];then
        iptables -t nat -I OUTPUT -j ${XUNYOU_CHAIN} >/dev/null 2>&1
    fi
    
    iptables -t nat -n -L ${XUNYOU_CDN_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ];then
        iptables -t nat -N ${XUNYOU_CDN_CHAIN} >/dev/null 2>&1
    fi
    
    iptables -t nat -C ${XUNYOU_CDN_CHAIN} -p tcp --dport ${dst_port} -j REDIRECT --to-ports ${redirect_port} >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        iptables -t nat -A ${XUNYOU_CDN_CHAIN} -p tcp --dport ${dst_port} -j REDIRECT --to-ports ${redirect_port} >/dev/null 2>&1
    fi
    iptables -t nat -I ${XUNYOU_CHAIN} -d ${dst_ip} -p tcp --dport ${dst_port} -j ${XUNYOU_CDN_CHAIN} >/dev/null 2>&1
}

clear_rule()
{
    ip rule del from all fwmark 0x200 lookup main >/dev/null 2>&1
    ip rule del from all table 198 >/dev/null 2>&1
    
    ip route flush table 199 >/dev/null 2>&1
    ip rule delete table 199 >/dev/null 2>&1
    
    iptables -t nat -D POSTROUTING -o tun199 -j RETURN >/dev/null 2>&1
    
    iptables -t filter -D INPUT -i tun199 -j ACCEPT >/dev/null 2>&1
    iptables -t filter -D FORWARD -o tun199 -j ACCEPT >/dev/null 2>&1
    iptables -t filter -D FORWARD -i tun199 -j ACCEPT >/dev/null 2>&1
    
    iptables -t mangle -D INPUT -s 127.0.0.1/32 -p tcp -m tcp --dport 53 -j DROP >/dev/null 2>&1
    
    iptables -t nat -F ${XUNYOU_CDN_CHAIN} >/dev/null 2>&1
    iptables -t nat -F ${XUNYOU_CHAIN} >/dev/null 2>&1
    iptables -t nat -D OUTPUT -j ${XUNYOU_CHAIN} >/dev/null 2>&1
    iptables -t nat -X ${XUNYOU_CDN_CHAIN} >/dev/null 2>&1
    iptables -t nat -X ${XUNYOU_CHAIN} >/dev/null 2>&1
    
    iptables -t mangle -F XUNYOU >/dev/null 2>&1
    iptables -t mangle -D OUTPUT -j XUNYOU >/dev/null 2>&1
    iptables -t mangle -X XUNYOU >/dev/null 2>&1

    return 0
}

init_rule()
{
    #查看work目录是否存在，如果不存在则说明插件未启动，不用进行后续配置
    #if [ -d ${WORK_DIR} ]; then
    #
    #fi

    return 0
}

#called by fw3 framework
reload_fw() 
{
    return 0
}


#called by plugin-app
close_fw(){
    clear_rule
}

#called by plugin-app
check_fw(){
    check_rule
}

if [ "${ACTION}" != "stop_acc" ]; then
    env_init
    if [ $? -ne 0 ]; then
        exit 1
    fi
fi

case $1 in
    "reload")
        reload_fw
        ;;
    "open")
        open_fw
        ;;
    "close")
        close_fw
        ;;
    "status")
        check_fw
        if [ $? -ne 0 ]; then
            #2 is 规则丢失，需要重启进程
            exit 2
        fi
        ;;
    "start_acc")
        config_acc_rule $2 $3
        ;;
    "stop_acc")
        close_fw
        ;;
    "config_cdn")
        config_cdn_rule $2 $3 $4 $5
        ;;
    *)
    #others
    ;;
esac

exit 0