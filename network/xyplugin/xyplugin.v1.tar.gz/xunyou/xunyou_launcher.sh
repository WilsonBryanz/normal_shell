#!/bin/bash
cd /home/deck/xunyou
echo "🛠️ 正在应用 SteamDeck 模拟环境补丁..."
DEFAULT_IF=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}')
[ -z "$DEFAULT_IF" ] && DEFAULT_IF=$(ls /sys/class/net | grep -v lo | head -n 1)
DEFAULT_MAC=$(cat /sys/class/net/$DEFAULT_IF/address 2>/dev/null || echo "00:00:00:00:00:00")

# 修正 Bash 兼容性
find ./scripts -type f -name "*.sh" -exec sed -i '1s|/bin/sh|/bin/bash|' {} +

# 变量劫持：伪装硬件
sed -i -E "s/LAN_IF_NAME=\".*\"/LAN_IF_NAME=\"$DEFAULT_IF\"/g" scripts/xunyou_daemon.sh
sed -i -E "s/SYSTEM_TYPE=\".*\"/SYSTEM_TYPE=\"steam\"/g" scripts/xunyou_daemon.sh
sed -i -E "s/VENDOR=\".*\"/VENDOR=\"steam\"/g" scripts/xunyou_daemon.sh
sed -i -E "s/MODEL=\".*\"/MODEL=\"steam_deck\"/g" scripts/xunyou_daemon.sh
sed -i 's|FILEWALL_SHELL="${PLUGIN_DIR}/firewall.sh"|FILEWALL_SHELL="${PLUGIN_DIR}/scripts/xunyou_firewall.sh"|g' scripts/xunyou_daemon.sh

# 生成模拟配置
mkdir -p runtime_conf
PLUGIN_VER=$(cat version 2>/dev/null || echo "3.7.20")
cat > runtime_conf/plugin.conf <<CONF
{
    "pluginVer": "$PLUGIN_VER",
    "systemType": "steam",
    "builtIn": false,
    "ipsetEnable": false,
    "lanIf": "$DEFAULT_IF",
    "lanMac": "$DEFAULT_MAC",
    "routerVendor": "steam",
    "routerModel": "steam_deck",
    "routerVer": "1.0",
    "dhcpLeases": "/home/deck/xunyou/runtime_conf/dhcp.leases",
    "version": "$PLUGIN_VER"
}
CONF
    # 生成空 base 配置以消除 config file is not exist 警告（非致命，仅静默）
    touch runtime_conf/base.cfg
    chmod 644 runtime_conf/base.cfg
echo "✅ 补丁完成，启动核心引擎..."
bash scripts/xunyou_daemon.sh start
