#!/bin/sh
# iStoreOS Gost Forward Manager V2.3.0 fresh installer
# Installs a clean, empty manager and (by default) downloads Gost v3 from its official release.
# This installer refuses to overwrite a previous Gost Forward Manager deployment.
set -u

BASE=$(CDPATH= cd "$(dirname "$0")" && pwd)
GOST_ROOT=/etc/gost-forward
DST_UU=/usr/bin/uu
DST_UU_ALT=/usr/sbin/uu
DST_COMPAT=/usr/bin/gost-forward
DST_HELPER=/usr/libexec/gost-forward-web
DST_TCPING=/usr/libexec/gost-forward-tcping
DST_CTRL=/usr/lib/lua/luci/controller/gost_forward_web.lua
DST_RULES=/usr/lib/lua/luci/view/gost-forward-web/rules.htm
DST_LOGS=/usr/lib/lua/luci/view/gost-forward-web/logs.htm
DST_INIT=/etc/init.d/gost-forward
GOST_BIN=/usr/bin/gost

SRC_UU="$BASE/usr/bin/uu"
SRC_HELPER="$BASE/usr/libexec/gost-forward-web"
SRC_TCPING="$BASE/usr/libexec/gost-forward-tcping"
SRC_CTRL="$BASE/usr/lib/lua/luci/controller/gost_forward_web.lua"
SRC_RULES="$BASE/usr/lib/lua/luci/view/gost-forward-web/rules.htm"
SRC_LOGS="$BASE/usr/lib/lua/luci/view/gost-forward-web/logs.htm"

say() { printf '%s\n' "$*"; }
fail() { printf '错误：%s\n' "$*" >&2; }
require_file() { [ -f "$1" ] || { fail "安装包缺少文件：$1"; exit 1; }; }

cleanup_failed() {
    say '安装未完成，正在清理本次新建的管理器文件……'
    [ -x "$DST_INIT" ] && "$DST_INIT" stop >/dev/null 2>&1 || true
    [ -x "$DST_INIT" ] && "$DST_INIT" disable >/dev/null 2>&1 || true
    sed -i '/# gost-forward-expire$/d;/# gost-forward-snapshot$/d;/# uu-expire$/d;/# uu-snapshot$/d' /etc/crontabs/root 2>/dev/null || true
    sed -i '\|^/etc/gost-forward$|d;\|^/etc/init.d/gost-forward$|d;\|^/usr/bin/uu$|d;\|^/usr/sbin/uu$|d;\|^/usr/bin/gost-forward$|d;\|^/usr/bin/gost$|d' /etc/sysupgrade.conf 2>/dev/null || true
    rm -f "$DST_INIT" "$DST_UU" "$DST_UU_ALT" "$DST_COMPAT" "$DST_HELPER" "$DST_TCPING" "$DST_CTRL" "$DST_RULES" "$DST_LOGS"
    rmdir /usr/lib/lua/luci/view/gost-forward-web 2>/dev/null || true
    rm -rf "$GOST_ROOT"
    if [ "${GOST_WRITTEN:-0}" = 1 ]; then rm -f "$GOST_BIN"; fi
}

on_error() { cleanup_failed; exit 1; }

[ "$(id -u)" = 0 ] || { fail '请使用 root 执行安装器。'; exit 1; }
case "$(uname -m 2>/dev/null)" in
    x86_64|amd64) ;;
    *) fail "本全新安装包内置的 TCPing 组件仅适用于 x86_64；当前架构：$(uname -m 2>/dev/null || echo unknown)。"; exit 1 ;;
esac
[ -x /sbin/procd ] || command -v ubus >/dev/null 2>&1 || { fail '未检测到 OpenWrt / iStoreOS 的 procd 或 ubus。'; exit 1; }

for f in "$SRC_UU" "$SRC_HELPER" "$SRC_TCPING" "$SRC_CTRL" "$SRC_RULES" "$SRC_LOGS"; do require_file "$f"; done
sh -n "$SRC_UU" || { fail '候选 uu Shell 语法检查失败。'; exit 1; }
sh -n "$SRC_HELPER" || { fail '候选 Web helper Shell 语法检查失败。'; exit 1; }
if command -v luac >/dev/null 2>&1; then
    luac -p "$SRC_CTRL" || { fail '候选 LuCI controller Lua 语法检查失败。'; exit 1; }
elif command -v lua >/dev/null 2>&1; then
    lua -e "assert(loadfile('$SRC_CTRL'))" || { fail '候选 LuCI controller Lua 语法检查失败。'; exit 1; }
fi
"$SRC_TCPING" --self-test >/dev/null 2>&1 || { fail '内置 TCPing 组件无法在当前 x86_64 系统运行。'; exit 1; }

# A fresh installer must never replace a possibly active or unknown deployment.
for f in "$GOST_ROOT" "$DST_UU" "$DST_UU_ALT" "$DST_COMPAT" "$DST_HELPER" "$DST_TCPING" "$DST_CTRL" "$DST_RULES" "$DST_LOGS" "$DST_INIT"; do
    [ ! -e "$f" ] || { fail "检测到已有文件或目录：$f"; fail '这是全新安装器，为避免覆盖现有项目，已停止。请改用对应升级包。'; exit 1; }
done
[ ! -e "$GOST_BIN" ] || { fail "检测到已有 Gost 二进制：$GOST_BIN"; fail '为避免影响其它 Gost 服务，全新安装器不会复用或覆盖它。'; exit 1; }

printf '将部署 V2.3.0 空规则管理器，并默认从 Gost 官方 Release 下载 Gost v3。继续？[Y/n]: '
read -r ANSWER
case "${ANSWER:-Y}" in
    y|Y|yes|YES|'') INSTALL_GOST=1 ;;
    n|N|no|NO) INSTALL_GOST=0 ;;
    *) fail '输入无效，已取消。'; exit 1 ;;
esac

# Install program files atomically before invoking the project bootstrap.
mkdir -p /usr/bin /usr/sbin /usr/libexec /usr/lib/lua/luci/controller /usr/lib/lua/luci/view/gost-forward-web || { fail '无法创建程序目录。'; exit 1; }
copy_new() {
    src="$1"; dst="$2"; mode="$3"; tmp="$dst.fresh.$$"
    rm -f "$tmp"
    cp "$src" "$tmp" || return 1
    chmod "$mode" "$tmp" || { rm -f "$tmp"; return 1; }
    mv "$tmp" "$dst" || { rm -f "$tmp"; return 1; }
}
copy_new "$SRC_UU" "$DST_UU" 755 || on_error
copy_new "$SRC_HELPER" "$DST_HELPER" 755 || on_error
copy_new "$SRC_TCPING" "$DST_TCPING" 755 || on_error
copy_new "$SRC_CTRL" "$DST_CTRL" 644 || on_error
copy_new "$SRC_RULES" "$DST_RULES" 644 || on_error
copy_new "$SRC_LOGS" "$DST_LOGS" 644 || on_error
ln -s "$DST_UU" "$DST_UU_ALT" || on_error
ln -s "$DST_UU" "$DST_COMPAT" || on_error

# bootstrap initializes only project directories, empty 14-column rule files, procd, sysupgrade persistence,
# and the once-per-minute expiry task. It creates no traffic sampling task.
"$DST_UU" bootstrap || on_error

if [ "$INSTALL_GOST" = 1 ]; then
    say '正在下载并校验官方 Gost v3；此步骤需要设备可访问 GitHub Release。'
    # Target was confirmed absent before installation. Mark it before the call so a partial failed write is cleaned.
    GOST_WRITTEN=1
    "$DST_UU" install-gost-online || on_error
else
    say '已部署管理器但未安装 Gost 核心。稍后可执行：uu install-gost-online 或 uu install-gost-local'
fi

# Make the new direct menu route visible without restarting Gost, procd, or cron.
rm -f /tmp/luci-indexcache /tmp/luci-indexcache.* 2>/dev/null || true
[ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd reload >/dev/null 2>&1 || true

say '================================================'
say 'V2.3.0 全新安装完成。'
say 'LuCI：主菜单“Gost 转发管理”直接进入转发管理；右上角切换“日志”。'
say '入口命令：uu'
if [ "$INSTALL_GOST" = 1 ]; then
    say 'Gost：已下载、校验并按空规则配置启动。'
else
    say 'Gost：尚未安装，因此页面会显示 Gost 异常，直到安装核心。'
fi
say '已创建空的 forward_rules.conf 与 protected_rules.conf；未导入任何规则或保护规则。'
say '未改 WAN、防火墙、DNAT、端口映射、DMZ、默认路由、策略路由或接口配置。'
say '================================================'
exit 0
