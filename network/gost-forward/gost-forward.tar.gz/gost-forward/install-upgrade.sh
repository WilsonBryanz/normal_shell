#!/bin/sh
# iStoreOS Gost Forward Manager V2.3.0 upgrade installer
# Upgrades an existing Gost Forward Manager deployment in-place.
# Preserves all rules, protected rules, YAML config, logs, and Gost binary.
# Only replaces program files (uu, helper, tcping, LuCI controller/views).
set -u

BASE=$(CDPATH= cd "$(dirname "$0")" && pwd)
GOST_ROOT=/etc/gost-forward
DST_UU=/usr/bin/uu
DST_UU_ALT=/usr/sbin/uu
DST_COMPAT=/usr/bin/gost-forward
DST_HELPER=/usr/libexec/gost-forward-web
DST_TCPING=/usr/libexec/gost-forward-tcping
DST_CTRL=/usr/lib/lua/luci/controller/gost_forward_web.lua
DST_RULES=/usr/lib/lua/luci/view/gost-forward-web/rules.htm
DST_LOGS=/usr/lib/lua/luci/view/gost-forward-web/logs.htm
DST_INIT=/etc/init.d/gost-forward
GOST_BIN=/usr/bin/gost

SRC_UU="$BASE/usr/bin/uu"
SRC_HELPER="$BASE/usr/libexec/gost-forward-web"
SRC_TCPING="$BASE/usr/libexec/gost-forward-tcping"
SRC_CTRL="$BASE/usr/lib/lua/luci/controller/gost_forward_web.lua"
SRC_RULES="$BASE/usr/lib/lua/luci/view/gost-forward-web/rules.htm"
SRC_LOGS="$BASE/usr/lib/lua/luci/view/gost-forward-web/logs.htm"

BACKUP_DIR="/tmp/gost-forward-backup-$(date +%Y%m%d%H%M%S)"

say() { printf '%s\n' "$*"; }
fail() { printf '错误：%s\n' "$*" >&2; }
require_file() { [ -f "$1" ] || { fail "安装包缺少文件：$1"; exit 1; }; }

rollback() {
    say ''
    say '========================================'
    say '升级失败，正在回滚……'
    say '========================================'
    if [ -d "$BACKUP_DIR" ]; then
        # Restore program files from backup
        for item in uu gost-forward-web gost-forward-tcping gost_forward_web.lua rules.htm logs.htm; do
            case "$item" in
                uu)
                    [ -f "$BACKUP_DIR/uu" ] && cp "$BACKUP_DIR/uu" "$DST_UU" && chmod 755 "$DST_UU"
                    ;;
                gost-forward-web)
                    [ -f "$BACKUP_DIR/gost-forward-web" ] && cp "$BACKUP_DIR/gost-forward-web" "$DST_HELPER" && chmod 755 "$DST_HELPER"
                    ;;
                gost-forward-tcping)
                    [ -f "$BACKUP_DIR/gost-forward-tcping" ] && cp "$BACKUP_DIR/gost-forward-tcping" "$DST_TCPING" && chmod 755 "$DST_TCPING"
                    ;;
                gost_forward_web.lua)
                    [ -f "$BACKUP_DIR/gost_forward_web.lua" ] && cp "$BACKUP_DIR/gost_forward_web.lua" "$DST_CTRL" && chmod 644 "$DST_CTRL"
                    ;;
                rules.htm)
                    [ -f "$BACKUP_DIR/rules.htm" ] && cp "$BACKUP_DIR/rules.htm" "$DST_RULES" && chmod 644 "$DST_RULES"
                    ;;
                logs.htm)
                    [ -f "$BACKUP_DIR/logs.htm" ] && cp "$BACKUP_DIR/logs.htm" "$DST_LOGS" && chmod 644 "$DST_LOGS"
                    ;;
            esac
        done
        # Restore rules if they were backed up
        [ -f "$BACKUP_DIR/forward_rules.conf" ] && cp "$BACKUP_DIR/forward_rules.conf" "$GOST_ROOT/forward_rules.conf"
        [ -f "$BACKUP_DIR/protected_rules.conf" ] && cp "$BACKUP_DIR/protected_rules.conf" "$GOST_ROOT/protected_rules.conf"
        [ -f "$BACKUP_DIR/gost.yaml" ] && cp "$BACKUP_DIR/gost.yaml" "$GOST_ROOT/gost.yaml"
    fi
    # Restart service with old files
    if [ -x "$DST_INIT" ]; then
        "$DST_INIT" restart >/dev/null 2>&1 || true
    fi
    say '回滚完成，服务已恢复至升级前状态。'
    exit 1
}

on_error() { rollback; }

# --- Pre-flight checks ---
[ "$(id -u)" = 0 ] || { fail '请使用 root 执行升级器。'; exit 1; }
case "$(uname -m 2>/dev/null)" in
    x86_64|amd64) ;;
    *) fail "本升级包内置的 TCPing 组件仅适用于 x86_64；当前架构：$(uname -m 2>/dev/null || echo unknown)。"; exit 1 ;;
esac
[ -x /sbin/procd ] || command -v ubus >/dev/null 2>&1 || { fail '未检测到 OpenWrt / iStoreOS 的 procd 或 ubus。'; exit 1; }

# Verify source files
for f in "$SRC_UU" "$SRC_HELPER" "$SRC_TCPING" "$SRC_CTRL" "$SRC_RULES" "$SRC_LOGS"; do require_file "$f"; done
sh -n "$SRC_UU" || { fail '候选 uu Shell 语法检查失败。'; exit 1; }
sh -n "$SRC_HELPER" || { fail '候选 Web helper Shell 语法检查失败。'; exit 1; }
if command -v luac >/dev/null 2>&1; then
    luac -p "$SRC_CTRL" || { fail '候选 LuCI controller Lua 语法检查失败。'; exit 1; }
elif command -v lua >/dev/null 2>&1; then
    lua -e "assert(loadfile('$SRC_CTRL'))" || { fail '候选 LuCI controller Lua 语法检查失败。'; exit 1; }
fi
"$SRC_TCPING" --self-test >/dev/null 2>&1 || { fail '内置 TCPing 组件无法在当前 x86_64 系统运行。'; exit 1; }

# --- Verify existing installation ---
MISSING=""
for f in "$GOST_ROOT" "$DST_UU" "$DST_HELPER" "$DST_INIT"; do
    [ -e "$f" ] || MISSING="$MISSING $f"
done
if [ -n "$MISSING" ]; then
    fail "未检测到完整的现有 Gost Forward Manager 部署，缺少：$MISSING"
    fail '这是升级器，仅适用于已有部署的设备。全新安装请使用 install-fresh.sh。'
    exit 1
fi

# --- Confirm upgrade ---
printf '\n'
printf '========================================\n'
printf '  Gost Forward Manager V2.3.0 升级器\n'
printf '========================================\n'
printf '\n'
printf '将执行以下操作：\n'
printf '  1. 备份现有规则、保护规则和 YAML 配置\n'
printf '  2. 停止 Gost 转发服务\n'
printf '  3. 替换程序文件（uu、helper、tcping、LuCI）\n'
printf '  4. 恢复备份的规则和配置\n'
printf '  5. 重启 Gost 转发服务\n'
printf '\n'
printf '不会修改：WAN、LAN、防火墙、DNAT、端口映射、路由。\n'
printf '不会覆盖：现有规则、保护规则、Gost 二进制、日志。\n'
printf '\n'
printf '继续升级？[Y/n]: '
read -r ANSWER
case "${ANSWER:-Y}" in
    y|Y|yes|YES|'') ;;
    *) say '已取消升级。'; exit 0 ;;
esac

# --- Backup existing data ---
say ''
say '正在备份现有配置……'
mkdir -p "$BACKUP_DIR" || { fail '无法创建备份目录。'; exit 1; }

# Backup program files (for rollback)
for src in "$DST_UU" "$DST_HELPER" "$DST_TCPING" "$DST_CTRL" "$DST_RULES" "$DST_LOGS"; do
    if [ -f "$src" ]; then
        cp "$src" "$BACKUP_DIR/" || { fail "备份失败：$src"; exit 1; }
    fi
done

# Backup rules and config
[ -f "$GOST_ROOT/forward_rules.conf" ] && cp "$GOST_ROOT/forward_rules.conf" "$BACKUP_DIR/"
[ -f "$GOST_ROOT/protected_rules.conf" ] && cp "$GOST_ROOT/protected_rules.conf" "$BACKUP_DIR/"
[ -f "$GOST_ROOT/gost.yaml" ] && cp "$GOST_ROOT/gost.yaml" "$BACKUP_DIR/"

say "备份已保存至：$BACKUP_DIR"

# --- Stop service ---
say '正在停止 Gost 转发服务……'
if [ -x "$DST_INIT" ]; then
    "$DST_INIT" stop >/dev/null 2>&1 || true
    sleep 1
fi

# --- Replace program files ---
say '正在替换程序文件……'

copy_new() {
    src="$1"; dst="$2"; mode="$3"; tmp="$dst.upgrade.$$"
    rm -f "$tmp"
    cp "$src" "$tmp" || return 1
    chmod "$mode" "$tmp" || { rm -f "$tmp"; return 1; }
    mv "$tmp" "$dst" || { rm -f "$tmp"; return 1; }
}

copy_new "$SRC_UU" "$DST_UU" 755 || on_error
copy_new "$SRC_HELPER" "$DST_HELPER" 755 || on_error
copy_new "$SRC_TCPING" "$DST_TCPING" 755 || on_error
copy_new "$SRC_CTRL" "$DST_CTRL" 644 || on_error
copy_new "$SRC_RULES" "$DST_RULES" 644 || on_error
copy_new "$SRC_LOGS" "$DST_LOGS" 644 || on_error

# Ensure symlinks exist
[ -L "$DST_UU_ALT" ] || ln -sf "$DST_UU" "$DST_UU_ALT"
[ -L "$DST_COMPAT" ] || ln -sf "$DST_UU" "$DST_COMPAT"

# --- Restore backed up rules ---
say '正在恢复规则和配置……'
[ -f "$BACKUP_DIR/forward_rules.conf" ] && cp "$BACKUP_DIR/forward_rules.conf" "$GOST_ROOT/forward_rules.conf"
[ -f "$BACKUP_DIR/protected_rules.conf" ] && cp "$BACKUP_DIR/protected_rules.conf" "$GOST_ROOT/protected_rules.conf"
[ -f "$BACKUP_DIR/gost.yaml" ] && cp "$BACKUP_DIR/gost.yaml" "$GOST_ROOT/gost.yaml"

# --- Restart service ---
say '正在重启 Gost 转发服务……'
if [ -x "$DST_INIT" ]; then
    "$DST_INIT" enable >/dev/null 2>&1 || true
    "$DST_INIT" restart >/dev/null 2>&1 || true
fi

# --- Refresh LuCI cache ---
rm -f /tmp/luci-indexcache /tmp/luci-indexcache.* 2>/dev/null || true
[ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd reload >/dev/null 2>&1 || true

# --- Verify service ---
sleep 2
if [ -x "$DST_INIT" ] && "$DST_INIT" running >/dev/null 2>&1; then
    SERVICE_STATUS='运行中'
else
    SERVICE_STATUS='未运行（请检查日志）'
fi

say ''
say '================================================'
say 'V2.3.0 升级完成。'
say '================================================'
say "备份目录：$BACKUP_DIR（升级成功后可在确认无误后手动删除）"
say "服务状态：$SERVICE_STATUS"
say ''
say '新增功能：'
say '  - 支持 tun31 / tun32 网口识别与显示'
say '  - TCP/UDP 协议下均可使用 tun31/tun32 作为出口接口'
say ''
say '未修改：'
say '  - 所有现有规则和保护规则已保留'
say '  - Gost 二进制未变动'
say '  - WAN、防火墙、DNAT、路由等系统配置未改动'
say '================================================'
exit 0
