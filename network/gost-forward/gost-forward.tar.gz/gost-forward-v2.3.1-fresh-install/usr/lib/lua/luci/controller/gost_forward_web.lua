module("luci.controller.gost_forward_web", package.seeall)

local http = require "luci.http"
local util = require "luci.util"
local fs = require "nixio.fs"
local dispatcher = require "luci.dispatcher"
local nixio = require "nixio"

local HELPER = "/usr/libexec/gost-forward-web"
local GOST_ROOT = "/etc/gost-forward"
local BACKUP_DIR = GOST_ROOT .. "/backup"
local EXPORT_DIR = GOST_ROOT .. "/export"
local UPLOAD_DIR = GOST_ROOT .. "/.web-upload"
local MAX_UPLOAD_BYTES = 2 * 1024 * 1024

local function helper_call(args)
    if not fs.access(HELPER, "x") then
        return '{"ok":false,"error":"Web 后端未安装或不可执行。"}'
    end
    local command = HELPER
    for _, value in ipairs(args or {}) do
        command = command .. " " .. util.shellquote(value or "")
    end
    local pipe = io.popen(command .. " 2>/dev/null")
    if not pipe then
        return '{"ok":false,"error":"无法启动 Web 后端。"}'
    end
    local body = pipe:read("*a") or ""
    pipe:close()
    if body == "" then
        return '{"ok":false,"error":"Web 后端没有返回内容。"}'
    end
    return body
end

local function json_error(message, status)
    if status then http.status(status, "Bad Request") end
    http.prepare_content("application/json")
    http.write(string.format('{"ok":false,"error":%q}', message or "请求失败。"))
end

local function valid_backup_name(name)
    return type(name) == "string" and name:match("^gost%-forward%-backup%-%d%d%d%d%d%d%d%d%-%d%d%d%d%d%d%.tar%.gz$") ~= nil
end

local function valid_export_name(name)
    return type(name) == "string" and name:match("^gost%-forward%-rules%-export%-%d%d%d%d%d%d%d%d%-%d%d%d%d%d%d%.txt$") ~= nil
end

local function ensure_upload_dir()
    if not fs.access(GOST_ROOT) then fs.mkdir(GOST_ROOT) end
    if not fs.access(UPLOAD_DIR) then fs.mkdir(UPLOAD_DIR) end
    return fs.access(UPLOAD_DIR)
end

local function make_upload_handler()
    local path, file, bytes, failed = nil, nil, 0, nil
    local pid = (nixio.getpid and nixio.getpid()) or 0
    math.randomseed(os.time() + pid)

    http.setfilehandler(function(meta, chunk, eof)
        if meta and meta.name == "upload_file" and not path then
            if not ensure_upload_dir() then
                failed = "无法创建安全上传目录。"
                return
            end
            path = string.format("%s/upload-%d-%d-%d", UPLOAD_DIR, os.time(), pid, math.random(100000, 999999))
            file = io.open(path, "wb")
            if not file then
                failed = "无法创建上传临时文件。"
                return
            end
        end
        if path and chunk and file and not failed then
            bytes = bytes + #chunk
            if bytes > MAX_UPLOAD_BYTES then
                failed = "上传文件超过 2 MiB 限制。"
            else
                file:write(chunk)
            end
        end
        if eof and file then
            file:close()
            file = nil
            if path then os.execute("chmod 600 " .. util.shellquote(path) .. " >/dev/null 2>&1") end
        end
    end)

    return function()
        if file then file:close() end
        if failed and path then os.remove(path) end
        return path, failed, bytes
    end
end

function index()
    if not fs.access(HELPER) then return end

    -- V2.3.0: direct main-menu entry. Standard iStoreOS sorts this immediately after Home.
    -- The Logs page remains routable but is hidden from the LuCI left-side menu and is
    -- switched from the page header instead.
    local root = entry({"admin", "gost-forward-web"}, template("gost-forward-web/rules"), _("Gost 转发管理"), 2)
    root.dependent = false

    local rules = entry({"admin", "gost-forward-web", "rules"}, call("action_rules_redirect"), nil)
    rules.leaf = true
    rules.hidden = true

    local logs = entry({"admin", "gost-forward-web", "logs"}, template("gost-forward-web/logs"), nil)
    logs.leaf = true
    logs.hidden = true

    local api = entry({"admin", "gost-forward-web", "api"}, call("action_api"), nil)
    api.leaf = true
    api.hidden = true

    local download = entry({"admin", "gost-forward-web", "download"}, call("action_download"), nil)
    download.leaf = true
    download.hidden = true

    -- Hidden compatibility redirects for the historical Services path.
    local legacy = entry({"admin", "services", "gost-forward-web"}, firstchild(), nil)
    legacy.dependent = false
    legacy.hidden = true
    local legacy_rules = entry({"admin", "services", "gost-forward-web", "rules"}, call("action_legacy_rules_redirect"), nil)
    legacy_rules.leaf = true
    local legacy_logs = entry({"admin", "services", "gost-forward-web", "logs"}, call("action_legacy_logs_redirect"), nil)
    legacy_logs.leaf = true
    local legacy_overview = entry({"admin", "services", "gost-forward-web", "overview"}, call("action_legacy_rules_redirect"), nil)
    legacy_overview.leaf = true
    local legacy_api = entry({"admin", "services", "gost-forward-web", "api"}, call("action_api"), nil)
    legacy_api.leaf = true
end

function action_rules_redirect()
    http.redirect(dispatcher.build_url("admin", "gost-forward-web"))
end

function action_legacy_rules_redirect()
    http.redirect(dispatcher.build_url("admin", "gost-forward-web", "rules"))
end

function action_legacy_logs_redirect()
    http.redirect(dispatcher.build_url("admin", "gost-forward-web", "logs"))
end

function action_download()
    local kind = http.formvalue("kind") or ""
    local name = http.formvalue("name") or ""
    local directory, content_type

    if kind == "backup" and valid_backup_name(name) then
        directory = BACKUP_DIR
        content_type = "application/gzip"
    elseif kind == "export" and valid_export_name(name) then
        directory = EXPORT_DIR
        content_type = "text/plain; charset=utf-8"
    else
        http.status(404, "Not Found")
        return
    end

    local path = directory .. "/" .. name
    local stat = fs.stat(path)
    if not stat or stat.type ~= "reg" then
        http.status(404, "Not Found")
        return
    end

    local file = io.open(path, "rb")
    if not file then
        http.status(404, "Not Found")
        return
    end
    http.prepare_content(content_type)
    http.header("Content-Disposition", 'attachment; filename="' .. name .. '"')
    while true do
        local chunk = file:read(8192)
        if not chunk then break end
        http.write(chunk)
    end
    file:close()
end

function action_api()
    local finish_upload = make_upload_handler()
    local action = http.formvalue("action") or "status"
    local allowed = {
        status=true, rules=true, interfaces=true, diagnostics=true, logs=true, yaml=true, sync=true,
        add=true, update=true, delete=true, delete_batch=true, clone_batch=true, update_batch=true, set_status_batch=true, diagnostic_tcping=true,
        protect=true, unprotect=true,
        backups=true, backup_create=true, backup_delete=true, export_rules=true,
        import_preview=true, import_commit=true, restore_preview=true, restore_commit=true
    }
    if not allowed[action] then
        local path = select(1, finish_upload())
        if path then os.remove(path) end
        json_error("不支持的操作。", 400)
        return
    end

    local upload_path, upload_error = finish_upload()
    if upload_error then
        json_error(upload_error, 400)
        return
    end

    local args = { action }
    local remove_upload = false

    if action == "add" then
        local rule_name = http.formvalue("rule_name")
        if not rule_name or rule_name == "" then rule_name = http.formvalue("alias") or "" end
        table.insert(args, rule_name)
        local keys = { "target", "local_port", "remote_port", "protocol", "companion_udp", "bind_if", "expire", "protect" }
        for _, key in ipairs(keys) do table.insert(args, http.formvalue(key) or "") end
    elseif action == "update" then
        local rule_name = http.formvalue("rule_name")
        if not rule_name or rule_name == "" then rule_name = http.formvalue("alias") or "" end
        table.insert(args, http.formvalue("index") or "")
        table.insert(args, rule_name)
        local keys = { "target", "local_port", "remote_port", "protocol", "companion_udp", "bind_if", "expire" }
        for _, key in ipairs(keys) do table.insert(args, http.formvalue(key) or "") end
    elseif action == "delete" then
        local keys = { "alias", "local_port", "protocol" }
        for _, key in ipairs(keys) do table.insert(args, http.formvalue(key) or "") end
    elseif action == "delete_batch" or action == "protect" or action == "unprotect" then
        table.insert(args, http.formvalue("indices") or "")
    elseif action == "clone_batch" then
        local keys = { "indices", "copy_suffix", "start_port" }
        for _, key in ipairs(keys) do table.insert(args, http.formvalue(key) or "") end
    elseif action == "update_batch" then
        local keys = { "indices", "target", "remote_port", "bind_if", "expire" }
        for _, key in ipairs(keys) do table.insert(args, http.formvalue(key) or "") end
    elseif action == "set_status_batch" then
        local keys = { "status", "indices" }
        for _, key in ipairs(keys) do table.insert(args, http.formvalue(key) or "") end
    elseif action == "diagnostic_tcping" then
        table.insert(args, http.formvalue("index") or "")
        table.insert(args, http.formvalue("interface") or "")
    elseif action == "backup_delete" then
        table.insert(args, http.formvalue("name") or "")
    elseif action == "export_rules" then
        table.insert(args, http.formvalue("indices") or "")
    elseif action == "import_preview" then
        if not upload_path then
            json_error("请选择普通规则导入文件。", 400)
            return
        end
        table.insert(args, upload_path)
        table.insert(args, http.formvalue("mode") or "")
        remove_upload = true
    elseif action == "import_commit" then
        table.insert(args, http.formvalue("token") or "")
        table.insert(args, http.formvalue("confirm") or "")
    elseif action == "restore_preview" then
        local backup_name = http.formvalue("backup_name") or ""
        if backup_name ~= "" then
            if not valid_backup_name(backup_name) then
                json_error("本地完整备份文件名非法。", 400)
                return
            end
            table.insert(args, BACKUP_DIR .. "/" .. backup_name)
        elseif upload_path then
            table.insert(args, upload_path)
            remove_upload = true
        else
            json_error("请选择本地备份或上传完整备份包。", 400)
            return
        end
    elseif action == "restore_commit" then
        table.insert(args, http.formvalue("token") or "")
        table.insert(args, http.formvalue("confirm") or "")
    end

    local body = helper_call(args)
    if remove_upload and upload_path then os.remove(upload_path) end
    http.prepare_content("application/json")
    http.write(body)
end
