#!/bin/sh
set -u
ROOT=/etc/gost-forward
UU=/usr/bin/uu
HELPER=/usr/libexec/gost-forward-web
TCPING=/usr/libexec/gost-forward-tcping
CTRL=/usr/lib/lua/luci/controller/gost_forward_web.lua
RULES=/usr/lib/lua/luci/view/gost-forward-web/rules.htm
LOGS=/usr/lib/lua/luci/view/gost-forward-web/logs.htm

bad=0
ok(){ printf 'OK  %s\n' "$*"; }
no(){ printf 'ERR %s\n' "$*" >&2; bad=1; }
need(){ [ -e "$1" ] && ok "$1" || no "缺失：$1"; }

printf '%s\n' '--- V2.3.1 全新安装只读验证 ---'
for f in "$UU" "$HELPER" "$TCPING" "$CTRL" "$RULES" "$LOGS" /etc/init.d/gost-forward "$ROOT/conf/forward_rules.conf" "$ROOT/conf/protected_rules.conf" "$ROOT/conf/gost.yaml"; do need "$f"; done
[ -L /usr/sbin/uu ] && [ "$(readlink /usr/sbin/uu 2>/dev/null)" = /usr/bin/uu ] && ok '/usr/sbin/uu 软链接' || no '/usr/sbin/uu 软链接异常'
[ -L /usr/bin/gost-forward ] && [ "$(readlink /usr/bin/gost-forward 2>/dev/null)" = /usr/bin/uu ] && ok '/usr/bin/gost-forward 软链接' || no '/usr/bin/gost-forward 软链接异常'
sh -n "$UU" && ok 'uu shell 语法' || no 'uu shell 语法'
sh -n "$HELPER" && ok 'Web helper shell 语法' || no 'Web helper shell 语法'
"$TCPING" --self-test >/dev/null 2>&1 && ok '内置 TCPing 自检' || no '内置 TCPing 自检'
if command -v luac >/dev/null 2>&1; then luac -p "$CTRL" && ok 'LuCI controller Lua 语法' || no 'LuCI controller Lua 语法'; elif command -v lua >/dev/null 2>&1; then lua -e "assert(loadfile('$CTRL'))" && ok 'LuCI controller Lua 语法' || no 'LuCI controller Lua 语法'; else printf 'SKIP LuCI controller Lua 语法（未安装 luac/lua 命令）\n'; fi

grep -q 'template("gost-forward-web/rules")' "$CTRL" && ok '菜单直接进入转发管理' || no '菜单入口不是直接转发管理'
grep -q '"Gost 转发管理"), 2' "$CTRL" && ok '主菜单优先级为 Home 后的位置' || no '主菜单优先级未确认'
grep -q 'logs.hidden = true' "$CTRL" && ok '日志未出现在左侧子菜单' || no '日志子菜单未隐藏'
grep -q '>日志</a>' "$RULES" && ok '转发页右侧日志切换' || no '转发页缺少日志切换'
grep -q '>转发管理</a>' "$LOGS" && ok '日志页右侧转发管理切换' || no '日志页缺少返回切换'
"$UU" validate >/dev/null 2>&1 && ok '空规则库严格校验' || no '空规则库严格校验'
[ -x /usr/bin/gost ] && /usr/bin/gost -V >/dev/null 2>&1 && ok 'Gost v3 可执行' || printf 'WARN Gost 尚未安装或不可执行（可运行 uu install-gost-online）\n'

[ "$bad" -eq 0 ] && { printf '%s\n' '验证完成：通过。'; exit 0; }
printf '%s\n' '验证完成：发现错误。'
exit 1
