/*
 * gost-forward-tcping: one IPv4 TCP handshake probe bound to a Linux interface.
 * No route, firewall, DNS, or interface configuration is changed.
 * DNS lookup is intentionally self-contained (A records only) so the helper does
 * not depend on BusyBox nc/curl/nslookup or glibc NSS modules.
 */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/if.h>
#include <poll.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

static long long now_ms(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000LL + tv.tv_usec / 1000;
}

static void emit(const char *state, const char *ip, const char *source, long long latency, const char *message) {
    printf("state=%s\n", state ? state : "failed");
    printf("target_ip=%s\n", ip ? ip : "");
    printf("source_ip=%s\n", source ? source : "");
    printf("latency_ms=%lld\n", latency < 0 ? 0 : latency);
    printf("message=%s\n", message ? message : "");
}

static const char *errno_state(int e) {
    switch (e) {
        case ECONNREFUSED: return "refused";
        case ETIMEDOUT: return "timeout";
        case ENETUNREACH: return "network_unreachable";
        case EHOSTUNREACH: return "host_unreachable";
        case ENETDOWN: return "network_down";
        case EADDRNOTAVAIL: return "source_unavailable";
        case ENODEV: return "interface_missing";
        default: return "connect_failed";
    }
}

static uint16_t rd16(const unsigned char *p) { return (uint16_t)((p[0] << 8) | p[1]); }
static uint32_t rd32(const unsigned char *p) { return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }
static void wr16(unsigned char *p, uint16_t v) { p[0] = (unsigned char)(v >> 8); p[1] = (unsigned char)(v & 0xff); }

static int read_nameserver(struct in_addr *out) {
    FILE *f = fopen("/etc/resolv.conf", "r");
    char line[256], addr[128];
    if (!f) return -1;
    while (fgets(line, sizeof(line), f)) {
        if (sscanf(line, " nameserver %127s", addr) == 1 || sscanf(line, "nameserver %127s", addr) == 1) {
            if (inet_pton(AF_INET, addr, out) == 1) { fclose(f); return 0; }
        }
    }
    fclose(f);
    return -1;
}

static int encode_qname(const char *host, unsigned char *out, size_t cap, size_t *written) {
    size_t n = strlen(host), pos = 0, start = 0;
    if (n == 0 || n > 253) return -1;
    while (start < n) {
        size_t end = start;
        while (end < n && host[end] != '.') {
            if (!isalnum((unsigned char)host[end]) && host[end] != '-') return -1;
            end++;
        }
        size_t len = end - start;
        if (len == 0 || len > 63 || pos + 1 + len >= cap) return -1;
        out[pos++] = (unsigned char)len;
        memcpy(out + pos, host + start, len);
        pos += len;
        start = end + 1;
        if (end == n) break;
    }
    if (pos + 1 > cap) return -1;
    out[pos++] = 0;
    *written = pos;
    return 0;
}

static int skip_name(const unsigned char *buf, size_t len, size_t *off) {
    size_t p = *off;
    int jumps = 0;
    while (p < len) {
        unsigned char c = buf[p];
        if (c == 0) { p++; *off = p; return 0; }
        if ((c & 0xc0) == 0xc0) {
            if (p + 1 >= len) return -1;
            p += 2;
            *off = p;
            return 0;
        }
        if (c & 0xc0 || c > 63 || p + 1 + c > len || ++jumps > 128) return -1;
        p += 1 + c;
    }
    return -1;
}

static int resolve_a_record(const char *host, struct in_addr *out) {
    if (inet_pton(AF_INET, host, out) == 1) return 0;
    struct in_addr ns;
    if (read_nameserver(&ns) != 0) return -1;
    unsigned char q[512], r[1536];
    size_t qname_len = 0;
    if (encode_qname(host, q + 12, sizeof(q) - 16, &qname_len) != 0) return -1;
    uint16_t id = (uint16_t)((getpid() ^ time(NULL) ^ (uintptr_t)host) & 0xffff);
    memset(q, 0, 12);
    wr16(q, id);
    wr16(q + 2, 0x0100);
    wr16(q + 4, 1);
    wr16(q + 12 + qname_len, 1);
    wr16(q + 14 + qname_len, 1);
    size_t qlen = 16 + qname_len;

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return -1;
    struct sockaddr_in dst;
    memset(&dst, 0, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(53);
    dst.sin_addr = ns;
    if (connect(fd, (struct sockaddr *)&dst, sizeof(dst)) != 0 || send(fd, q, qlen, 0) != (ssize_t)qlen) { close(fd); return -1; }
    struct pollfd pfd;
    pfd.fd = fd; pfd.events = POLLIN; pfd.revents = 0;
    if (poll(&pfd, 1, 2000) <= 0) { close(fd); return -1; }
    ssize_t rn = recv(fd, r, sizeof(r), 0);
    close(fd);
    if (rn < 12 || rd16(r) != id) return -1;
    uint16_t flags = rd16(r + 2), qd = rd16(r + 4), an = rd16(r + 6);
    if ((flags & 0x000f) != 0 || an == 0) return -1;
    size_t off = 12;
    for (uint16_t n = 0; n < qd; n++) {
        if (skip_name(r, (size_t)rn, &off) != 0 || off + 4 > (size_t)rn) return -1;
        off += 4;
    }
    for (uint16_t n = 0; n < an; n++) {
        if (skip_name(r, (size_t)rn, &off) != 0 || off + 10 > (size_t)rn) return -1;
        uint16_t type = rd16(r + off), cls = rd16(r + off + 2), rdlen = rd16(r + off + 8);
        (void)rd32(r + off + 4);
        off += 10;
        if (off + rdlen > (size_t)rn) return -1;
        if (type == 1 && cls == 1 && rdlen == 4) {
            memcpy(out, r + off, 4);
            return 0;
        }
        off += rdlen;
    }
    return -1;
}

static void usage(void) {
    fprintf(stderr, "usage: gost-forward-tcping -I INTERFACE [-t TIMEOUT_MS] HOST PORT\n");
}

int main(int argc, char **argv) {
    const char *iface = NULL, *host = NULL, *port = NULL;
    int timeout_ms = 3000, i;
    if (argc == 2 && strcmp(argv[1], "--self-test") == 0) {
        emit("self_test_ok", "", "", 0, "helper runnable"); return 0;
    }
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-I") == 0 && i + 1 < argc) iface = argv[++i];
        else if (strcmp(argv[i], "-t") == 0 && i + 1 < argc) timeout_ms = atoi(argv[++i]);
        else if (!host) host = argv[i];
        else if (!port) port = argv[i];
        else { usage(); return 64; }
    }
    if (!iface || !host || !port || !*iface || !*host || !*port || strlen(iface) >= IFNAMSIZ || timeout_ms < 100 || timeout_ms > 10000) { usage(); return 64; }
    char *endp = NULL; long p = strtol(port, &endp, 10);
    if (!endp || *endp || p < 1 || p > 65535) { emit("invalid_port", "", "", 0, "invalid TCP port"); return 65; }

    struct in_addr target_addr;
    if (resolve_a_record(host, &target_addr) != 0) { emit("resolve_failed", "", "", 0, "IPv4 resolution failed"); return 66; }
    char target_ip[INET_ADDRSTRLEN] = "";
    inet_ntop(AF_INET, &target_addr, target_ip, sizeof(target_ip));

    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (fd < 0) { emit("socket_failed", target_ip, "", 0, "unable to create TCP socket"); return 67; }
    if (setsockopt(fd, SOL_SOCKET, SO_BINDTODEVICE, iface, strlen(iface) + 1) != 0) {
        int e = errno; close(fd);
        emit(e == ENODEV ? "interface_missing" : "bind_interface_failed", target_ip, "", 0,
             e == ENODEV ? "selected interface does not exist" : "unable to bind socket to selected interface");
        return 68;
    }
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) { close(fd); emit("socket_failed", target_ip, "", 0, "unable to configure TCP socket"); return 69; }
    struct sockaddr_in dst;
    memset(&dst, 0, sizeof(dst)); dst.sin_family = AF_INET; dst.sin_port = htons((uint16_t)p); dst.sin_addr = target_addr;
    long long start = now_ms();
    int rc = connect(fd, (struct sockaddr *)&dst, sizeof(dst));
    int final_errno = 0;
    if (rc != 0 && errno == EINPROGRESS) {
        struct pollfd pfd; pfd.fd = fd; pfd.events = POLLOUT; pfd.revents = 0;
        rc = poll(&pfd, 1, timeout_ms);
        if (rc == 0) { close(fd); emit("timeout", target_ip, "", now_ms()-start, "TCP connect timed out"); return 70; }
        if (rc < 0) final_errno = errno;
        else { socklen_t slen = sizeof(final_errno); if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &final_errno, &slen) != 0) final_errno = errno; }
    } else if (rc != 0) final_errno = errno;
    if (final_errno != 0) { close(fd); emit(errno_state(final_errno), target_ip, "", now_ms()-start, "TCP connect failed"); return 71; }

    struct sockaddr_in src; socklen_t src_len = sizeof(src); char source_ip[INET_ADDRSTRLEN] = "";
    memset(&src, 0, sizeof(src));
    if (getsockname(fd, (struct sockaddr *)&src, &src_len) == 0) inet_ntop(AF_INET, &src.sin_addr, source_ip, sizeof(source_ip));
    close(fd);
    emit("success", target_ip, source_ip, now_ms()-start, "TCP handshake established");
    return 0;
}
