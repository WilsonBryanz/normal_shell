# iStoreOS Gost 转发管理 V2.3.1 全新安装版

此包用于**没有现有 Gost Forward Manager 项目文件**的 iStoreOS / OpenWrt x86_64 设备。

它不是升级包：检测到 `/etc/gost-forward`、`/usr/bin/uu`、LuCI 页面、init 服务或已有 `/usr/bin/gost` 时会拒绝继续，避免覆盖未知部署。已有项目请继续使用对应升级包。

## 全新安装后包含

- 单 Gost 进程、单 procd 服务的转发管理器。
- 严格 14 列规则模型；空规则库初始化，不携带任何旧设备规则、账号、密码、保护规则、YAML、日志、数据库或流量记录。
- 转发管理、导入/导出、完整备份/恢复、保护规则、启用/禁用、移动端卡片、分页、接口摘要、日志、诊断与内置 TCPing。
- 内置的 TCPing 组件仅适用于 x86_64；其源码位于 `tool-source/gost-forward-tcping.c`。
- 默认从 Gost 官方 GitHub Release 下载、校验并安装 Gost v3；安装前可以选择跳过，之后再执行 `uu install-gost-online` 或 `uu install-gost-local`。

## 支持的接口

转发管理器支持以下虚拟网口类型，用于选择出口接口：

| 接口类型 | 接口名称 | 协议支持 |
|----------|----------|----------|
| TUN 接口 | `tun163`、`tun164`、`tun31`、`tun32` | TCP / UDP |
| TAP 接口 | `tap*` | TCP / UDP |
| WireGuard | `wg*` | TCP 专用 |

> **说明**：
> - `tun31` 和 `tun32` 为 V2.3.1 新增支持的 TUN 接口，功能与 `tun163`、`tun164` 完全一致。
> - TCP 协议下所有 TUN/TAP/WireGuard 接口均可用；UDP 协议仅支持 `tun163`、`tun164`、`tun31`、`tun32` 四种 TUN 接口。
> - 接口列表由系统自动检测生成，仅显示设备上实际存在的网口。

## LuCI 菜单

- “Gost 转发管理”注册为 iStoreOS 主菜单优先级 `2`，设计为标准 iStoreOS 中紧接“首页”的位置。
- 点击主菜单直接进入“转发管理”。
- 左侧不显示“转发管理 / 日志”子菜单。
- 规则页右上角使用“日志”切换；日志页右上角使用“转发管理”切换。

不同 iStoreOS 主题若自行重排同优先级菜单项，最终视觉顺序可能会略有差异；该包不会修改其它菜单项。

## 安装

将本压缩包上传到目标设备后：

```sh
cd /tmp
tar -xzf gost-forward-v2.3.0-fresh-install.tar.gz
cd gost-forward-v2.3.0-fresh-install
sh ./install-fresh.sh
```

默认回答 `Y` 会自动：

1. 安装 `curl` 与 CA 证书（仅在系统缺少 curl 时，使用 opkg 或 apk）。
2. 从官方 Gost Release 下载并 SHA-256 校验 Gost v3。
3. 创建空的项目目录、空规则库、保护规则库、YAML、procd 服务和入口命令。
4. 启用 Gost 服务；空规则服务没有任何业务监听端口。
5. 写入一次每分钟的**到期状态收口** cron；不会创建流量采样 cron。
6. 重新加载 uhttpd，使 LuCI 菜单即时出现。

## 不会修改

- WAN、LAN、默认路由、策略路由、WireGuard AllowedIPs、接口配置。
- 防火墙、DNAT、端口映射、上级 DMZ。
- 任何来自旧设备的规则、保护规则、账号、密码、备份、日志或流量数据库。

## 安装后验证

```sh
sh ./verify-fresh-install.sh
```

## 初始使用

1. 打开 LuCI → `Gost 转发管理`。
2. 点击“新增”，创建规则草稿。
3. 选择有效出口接口、目标地址和端口，保存后由候选事务同步。
4. 需要保护的基础规则先正常创建，再在页面勾选并设置保护。

## 版本更新日志

详细的版本变更记录请参阅 [CHANGELOG.md](./CHANGELOG.md)。

