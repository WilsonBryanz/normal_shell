#!/bin/bash
cd /home/deck/uu

# 每次启动前自动清理旧的pid文件，避免残留
rm -f ./*.pid 2>/dev/null || true

# 自动改小文件描述符限制，解决大系统的启动卡住问题
ulimit -n 1024

DEFAULT_IF=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}')
[ -z "$DEFAULT_IF" ] && DEFAULT_IF=$(ls /sys/class/net | grep -v lo | head -n 1)

# 放行局域网 APP 发现协议与加速数据通道
iptables -I INPUT -p udp --dport 9999 -j ACCEPT 2>/dev/null || true
iptables -I INPUT -p tcp --dport 9080 -j ACCEPT 2>/dev/null || true
iptables -I INPUT -p tcp --dport 9443 -j ACCEPT 2>/dev/null || true
iptables -I INPUT -p tcp --dport 8000 -j ACCEPT 2>/dev/null || true
iptables -I INPUT -p tcp --dport 8080 -j ACCEPT 2>/dev/null || true

# 核心修补与伪装注入
find ./ -type f -name "*.sh" -exec sed -i '1s|/bin/sh|/bin/bash|' {} +

# 封印官方自动更新
sed -i 's/check_plugin_upgrade/true/g' uuplugin_monitor.sh

echo "🚀 守护引擎已启动，后台运行中..."
# 守护进程改为后台运行，并且把所有输出重定向到日志，彻底不干扰终端
bash uuplugin_monitor.sh > /var/log/uu_monitor.log 2>&1 &
